package com.example.mymusic.player

import android.content.ComponentName
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.mymusic.data.MusicRepository
import com.example.mymusic.data.MusicTrack
import com.example.mymusic.data.PlayerState
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PlayerViewModel(private val context: Context, private val repo: MusicRepository) : ViewModel() {
    private val _state = MutableStateFlow(PlayerState())
    val state = _state.asStateFlow()
    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private var initialized = false
    private var persistenceJob: Job? = null
    private val prefs = PlaybackPreferences(context)

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = publish()
    }

    fun connect(onReady: () -> Unit = {}) {
        if (future != null) return
        val token = SessionToken(context, ComponentName(context, MusicService::class.java))
        future = MediaController.Builder(context, token).buildAsync()
        future!!.addListener({
            controller = future!!.get()
            controller!!.addListener(listener)
            publish()
            persistenceJob = viewModelScope.launch {
                while (true) {
                    delay(1000)
                    savePlayback()
                }
            }
            onReady()
        }, context.mainExecutor)
    }

    fun initialize() {
        if (initialized) return
        initialized = true
        viewModelScope.launch {
            val all = repo.tracks.first()
            val queue = prefs.queue().mapNotNull { id -> all.firstOrNull { it.id == id } }
            val saved = prefs.track()
            if (queue.isNotEmpty()) {
                val index = queue.indexOfFirst { it.id == saved }.coerceAtLeast(0)
                setQueue(queue, index, prefs.position(), false)
            }
        }
    }

    fun play(track: MusicTrack) {
        viewModelScope.launch {
            val all = repo.tracks.first()
            val list = if (all.isEmpty()) listOf(track) else all
            val index = list.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
            setQueue(list, index, 0L, true)
            repo.addHistory(track.id)
        }
    }

    fun setQueue(list: List<MusicTrack>, index: Int = 0, position: Long = 0L, play: Boolean = true) {
        val c = controller ?: return
        c.setMediaItems(list.map(::mediaItem), index, position)
        c.prepare()
        c.playWhenReady = play
        publish()
    }

    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { controller?.seekTo(ms.coerceAtLeast(0)) }
    fun shuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled; publish() } }
    fun repeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
            publish()
        }
    }

    private fun publish() {
        val c = controller ?: return
        val currentId = c.currentMediaItem?.mediaId
        val tracks = repo.tracks.value
        val current = currentId?.let { id -> tracks.firstOrNull { it.id == id } }
        val queue = (0 until c.mediaItemCount).mapNotNull { i ->
            tracks.firstOrNull { it.id == c.getMediaItemAt(i).mediaId }
        }
        _state.value = PlayerState(
            track = current,
            isPlaying = c.isPlaying,
            position = c.currentPosition.coerceAtLeast(0),
            duration = c.duration.coerceAtLeast(0),
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            queue = queue,
            currentIndex = c.currentMediaItemIndex
        )
    }

    private fun savePlayback() {
        val c = controller ?: return
        val ids = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).mediaId }
        prefs.save(c.currentMediaItem?.mediaId, c.currentPosition.coerceAtLeast(0), ids)
    }

    private fun mediaItem(track: MusicTrack): MediaItem = MediaItem.Builder()
        .setMediaId(track.id)
        .setUri(track.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(track.artist)
                .setAlbumTitle(track.album)
                .setArtworkUri(track.coverUri?.let(android.net.Uri::parse))
                .build()
        )
        .build()

    override fun onCleared() {
        savePlayback()
        persistenceJob?.cancel()
        controller?.removeListener(listener)
        future?.let(MediaController::releaseFuture)
        super.onCleared()
    }
}
