package com.example.mymusic.player

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.mymusic.data.MusicDatabase
import com.example.mymusic.data.MusicTrack
import com.example.mymusic.data.model
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

@OptIn(UnstableApi::class)
class MusicService : MediaSessionService() {
    private lateinit var player: ExoPlayer
    private lateinit var session: MediaSession
    private lateinit var prefs: PlaybackPreferences

    private val callback = object : MediaSession.Callback {
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            isForPlayback: Boolean
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val db = MusicDatabase.get(this@MusicService)
            val tracks = db.dao().tracksNow().map { it.model() }
            val ids = prefs.queue()
            val queue = ids.mapNotNull { id -> tracks.firstOrNull { it.id == id } }
            val savedId = prefs.track()
            val fallback = savedId?.let { id -> tracks.firstOrNull { it.id == id } }
            val effectiveQueue = if (queue.isNotEmpty()) queue else listOfNotNull(fallback)
            if (effectiveQueue.isEmpty()) {
                return Futures.immediateFuture(
                    MediaSession.MediaItemsWithStartPosition(emptyList(), 0, 0L)
                )
            }
            val index = effectiveQueue.indexOfFirst { it.id == savedId }.coerceAtLeast(0)
            val items = effectiveQueue.map(::mediaItem)
            val result = if (isForPlayback) {
                MediaSession.MediaItemsWithStartPosition(items, index, prefs.position())
            } else {
                MediaSession.MediaItemsWithStartPosition(listOf(items[index]), 0, prefs.position())
            }
            return Futures.immediateFuture(result)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = PlaybackPreferences(this)
        val attributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(attributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        session = MediaSession.Builder(this, player)
            .setCallback(callback)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.isPlaying) stopSelf()
    }

    override fun onDestroy() {
        session.release()
        player.release()
        super.onDestroy()
    }

    private fun mediaItem(track: MusicTrack): MediaItem = MediaItem.Builder()
        .setMediaId(track.id)
        .setUri(track.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(track.artist)
                .setAlbumTitle(track.album)
                .setArtworkUri(track.coverUri?.let(android.net.Uri::parse))
                .build()
        )
        .build()
}
