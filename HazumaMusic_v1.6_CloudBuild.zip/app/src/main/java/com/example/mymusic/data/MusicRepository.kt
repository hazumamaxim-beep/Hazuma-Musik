package com.example.mymusic.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MusicRepository(private val context: Context, private val db: MusicDatabase) {
    private val dao = db.dao()
    val tracks: Flow<List<MusicTrack>> = dao.tracks().let { flow -> kotlinx.coroutines.flow.flow { flow.collect { emit(it.map(TrackEntity::model)) } } }
    val favorites = dao.favorites()
    val history = dao.history()
    val playlists = dao.playlists()
    val stats = dao.stats()

    suspend fun importUris(uris: List<Uri>) = withContext(Dispatchers.IO) {
        val imported = uris.mapNotNull(::read)
        if (imported.isNotEmpty()) dao.upsertTracks(imported)
        uris.forEach {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }
    }

    suspend fun scanDevice() = withContext(Dispatchers.IO) {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION
        )
        val result = mutableListOf<TrackEntity>()
        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val id = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val album = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val duration = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val mediaId = cursor.getLong(id)
                val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mediaId.toString())
                val meta = readMetadata(uri)
                result += TrackEntity(
                    id = "media:$mediaId",
                    uri = uri.toString(),
                    title = meta?.title ?: cursor.getString(title).orEmpty().ifBlank { "Unknown title" },
                    artist = meta?.artist ?: cursor.getString(artist).orEmpty().ifBlank { "Unknown artist" },
                    album = meta?.album ?: cursor.getString(album).orEmpty().ifBlank { "Unknown album" },
                    duration = meta?.duration ?: cursor.getLong(duration),
                    coverUri = meta?.coverUri,
                    addedAt = System.currentTimeMillis()
                )
            }
        }
        if (result.isNotEmpty()) dao.upsertTracks(result)
    }

    suspend fun toggleFavorite(id: String) {
        if (dao.favorites().first().contains(id)) dao.removeFavorite(id) else dao.addFavorite(FavoriteEntity(id))
    }

    suspend fun addHistory(id: String) {
        val now = System.currentTimeMillis()
        dao.history(HistoryEntity(trackId = id, playedAt = now))
        val stat = dao.stat(id) ?: StatEntity(id)
        dao.upsertStat(stat.copy(playCount = stat.playCount + 1, lastPlayedAt = now))
    }

    suspend fun addPlayedTime(id: String, ms: Long) {
        val stat = dao.stat(id) ?: StatEntity(id)
        dao.upsertStat(stat.copy(totalPlayedMs = stat.totalPlayedMs + ms))
    }

    suspend fun clearHistory() = dao.clearHistory()
    suspend fun deleteTrack(track: MusicTrack) = dao.deleteTrack(track.id)
    suspend fun createPlaylist(name: String): Long = dao.createPlaylist(PlaylistEntity(name = name, createdAt = System.currentTimeMillis()))
    suspend fun deletePlaylist(id: Long) = dao.deletePlaylist(id)
    suspend fun addToPlaylist(pid: Long, tid: String) = dao.addToPlaylist(PlaylistTrackEntity(pid, tid, dao.nextPosition(pid)))
    fun playlistTracks(pid: Long) = dao.playlistTracks(pid)

    private data class Meta(val title: String, val artist: String, val album: String, val duration: Long, val coverUri: String?)

    private fun read(uri: Uri): TrackEntity? = readMetadata(uri)?.let {
        TrackEntity(uri.toString(), uri.toString(), it.title, it.artist, it.album, it.duration, it.coverUri, System.currentTimeMillis())
    }

    private fun readMetadata(uri: Uri): Meta? = runCatching {
        MediaMetadataRetriever().use { retriever ->
            retriever.setDataSource(context, uri)
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty().ifBlank { "Unknown title" }
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty().ifBlank { "Unknown artist" }
            val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty().ifBlank { "Unknown album" }
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val cover = retriever.embeddedPicture?.let { bytes ->
                val dir = File(context.filesDir, "covers").apply { mkdirs() }
                val file = File(dir, "${uri.toString().hashCode()}.jpg")
                if (!file.exists()) FileOutputStream(file).use { it.write(bytes) }
                Uri.fromFile(file).toString()
            }
            Meta(title, artist, album, duration, cover)
        }
    }.getOrNull()
}
