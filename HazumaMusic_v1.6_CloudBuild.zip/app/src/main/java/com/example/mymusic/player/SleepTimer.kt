package com.example.mymusic.player

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SleepTimer(private val scope: CoroutineScope, private val onFinish: () -> Unit) {
    private var job: Job? = null
    var remainingMinutes: Int = 0
        private set

    fun start(minutes: Int) {
        job?.cancel()
        remainingMinutes = minutes
        job = scope.launch {
            delay(minutes * 60_000L)
            remainingMinutes = 0
            onFinish()
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        remainingMinutes = 0
    }
}
