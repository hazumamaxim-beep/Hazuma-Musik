package com.example.mymusic

import android.os.Bundle
import android.Manifest
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import coil3.compose.AsyncImage
import com.example.mymusic.data.*
import com.example.mymusic.ai.HazumaAiService
import com.example.mymusic.ai.HazumaAiAgent
import com.example.mymusic.ai.HazumaAiAction
import com.example.mymusic.player.PlayerViewModel
import com.example.mymusic.player.SleepTimer
import kotlinx.coroutines.launch

private val Black = Color(0xFF08090B)
private val Surface = Color(0xFF111318)
private val Surface2 = Color(0xFF191C21)
private val Accent = Color(0xFFD7FF3F)
private val Muted = Color(0xFF979BA4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = MusicRepository(this, MusicDatabase.get(this))
        val aiService = HazumaAiService(this)
        setContent {
            val vm: PlayerViewModel = viewModel(factory = object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T =
                    PlayerViewModel(this@MainActivity, repo) as T
            })
            LaunchedEffect(Unit) { vm.connect { vm.initialize() } }
            HazumaApp(repo, vm, aiService)
        }
    }
}

@Composable
private fun HazumaApp(repo: MusicRepository, vm: PlayerViewModel, aiService: HazumaAiService) {
    val scope = rememberCoroutineScope()
    val tracks by repo.tracks.collectAsState(initial = emptyList())
    val favorites by repo.favorites.collectAsState(initial = emptyList())
    val playlists by repo.playlists.collectAsState(initial = emptyList())
    val player by vm.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var nowPlaying by remember { mutableStateOf(false) }
    var playlistDialog by remember { mutableStateOf(false) }
    var sleepDialog by remember { mutableStateOf(false) }
    var aiDialog by remember { mutableStateOf(false) }
    val sleepTimer = remember { SleepTimer(scope) { vm.toggle() } }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scope.launch { repo.scanDevice() }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch { repo.importUris(uris) }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Black, surface = Surface, primary = Accent, onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(
            containerColor = Black,
            bottomBar = {
                NavigationBar(containerColor = Surface) {
                    val items = listOf("Home" to Icons.Rounded.Home, "Search" to Icons.Rounded.Search, "Library" to Icons.Rounded.LibraryMusic, "AI" to Icons.Rounded.AutoAwesome, "Settings" to Icons.Rounded.Settings)
                    items.forEachIndexed { i, (name, icon) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, name) }, label = { Text(name) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    0 -> Home(tracks, favorites, vm::play,
                        scan = { if (android.os.Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.READ_MEDIA_AUDIO) else permission.launch(Manifest.permission.READ_EXTERNAL_STORAGE) },
                        import = { picker.launch(arrayOf("audio/*")) })
                    1 -> Search(query, { query = it }, tracks, vm::play)
                    2 -> Library(tracks, favorites, playlists, vm::play, { playlistDialog = true }, { picker.launch(arrayOf("audio/*")) })
                    3 -> AiScreen(aiService, repo, vm, tracks, player.track)
                    else -> SettingsScreen(
                        onClearHistory = { scope.launch { repo.clearHistory() } },
                        onSleep = { sleepDialog = true }
                    )
                }
                if (player.track != null) MiniPlayer(player) { nowPlaying = true; vm.toggle() }
            }
        }
        if (nowPlaying && player.track != null) NowPlaying(player, vm) { nowPlaying = false }
        if (playlistDialog) CreatePlaylistDialog(
            onCreate = { name -> scope.launch { repo.createPlaylist(name) }; playlistDialog = false },
            onDismiss = { playlistDialog = false }
        )
        if (sleepDialog) SleepTimerDialog(
            onSelect = { minutes -> sleepTimer.start(minutes); sleepDialog = false },
            onCancel = { sleepTimer.cancel(); sleepDialog = false },
            onDismiss = { sleepDialog = false }
        )
    }
}

@Composable private fun Header(title: String, subtitle: String? = null) = Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
    Text("HAZUMA MUSIC", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 1.8.sp)
    Spacer(Modifier.height(6.dp)); Text(title, fontSize = 31.sp, fontWeight = FontWeight.Bold)
    subtitle?.let { Text(it, color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 3.dp)) }
}

@Composable private fun Home(tracks: List<MusicTrack>, favorites: List<String>, play: (MusicTrack) -> Unit, scan: () -> Unit, import: () -> Unit) {
    Column {
        Header("Your music", "Local. Private. Yours.")
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = import, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("ADD MUSIC") }
            OutlinedButton(onClick = scan) { Icon(Icons.Rounded.Refresh, null); Spacer(Modifier.width(6.dp)); Text("SCAN") }
        }
        if (tracks.isEmpty()) EmptyState("Your library is empty", "Add local audio files to start listening.", import)
        else {
            SectionTitle("Recently added")
            LazyColumn { items(tracks.take(20), key = { it.id }) { TrackRow(it, it.id in favorites, play) } }
        }
    }
}

@Composable private fun Search(q: String, set: (String) -> Unit, tracks: List<MusicTrack>, play: (MusicTrack) -> Unit) {
    Column {
        Header("Search")
        OutlinedTextField(value = q, onValueChange = set, singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), placeholder = { Text("Songs, artists, albums") }, leadingIcon = { Icon(Icons.Rounded.Search, null) })
        val filtered = tracks.filter { q.isBlank() || it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
        LazyColumn { items(filtered, key = { it.id }) { TrackRow(it, false, play) } }
    }
}

@Composable private fun Library(tracks: List<MusicTrack>, favorites: List<String>, playlists: List<PlaylistEntity>, play: (MusicTrack) -> Unit, create: () -> Unit, import: () -> Unit) {
    var section by remember { mutableIntStateOf(0) }
    val artists = tracks.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() }
    val albums = tracks.groupBy { it.album }.toList().sortedBy { it.first.lowercase() }
    Column {
        Header("Library", "${tracks.size} tracks • ${playlists.size} playlists")
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = import, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)) { Text("ADD MUSIC") }
            OutlinedButton(onClick = create) { Icon(Icons.Rounded.Add, null); Text("PLAYLIST") }
        }
        TabRow(selectedTabIndex = section, containerColor = Color.Transparent) {
            listOf("Songs", "Artists", "Albums", "Playlists").forEachIndexed { i, name -> Tab(selected = section == i, onClick = { section = i }, text = { Text(name) }) }
        }
        when (section) {
            0 -> LazyColumn { items(tracks, key = { it.id }) { TrackRow(it, it.id in favorites, play) } }
            1 -> LazyColumn { items(artists, key = { it.first }) { (artist, songs) -> GroupRow(artist, "${songs.size} songs") { play(songs.first()) } } }
            2 -> LazyColumn { items(albums, key = { it.first }) { (album, songs) -> GroupRow(album, songs.first().artist + " • ${songs.size} songs") { play(songs.first()) } } }
            3 -> LazyColumn { items(playlists, key = { it.id }) { playlist -> GroupRow(playlist.name, "Playlist") {} } }
        }
    }
}

@Composable
private fun AiScreen(ai: HazumaAiService, repo: MusicRepository, vm: PlayerViewModel, tracks: List<MusicTrack>, current: MusicTrack?) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var sources by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    var loading by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var key by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val speechRecognizer = remember(context) { SpeechRecognizer.createSpeechRecognizer(context) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            listening = true
            speechRecognizer.startListening(intent)
        }
    }
    DisposableEffect(speechRecognizer) {
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                prompt = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                listening = false
            }
            override fun onError(error: Int) { listening = false }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        onDispose { speechRecognizer.destroy() }
    }
    Column(Modifier.fillMaxSize()) {
        Header("Hazuma AI", "Gemini ${HazumaAiService.DEFAULT_MODEL}")
        Card(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface)) {
            Column(Modifier.padding(18.dp)) {
                Text("AI music agent", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Hazuma AI can control playback, search your local library and answer current web questions.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(prompt, { prompt = it }, modifier = Modifier.weight(1f), minLines = 3,
                        placeholder = { Text("Например: создай плейлист для ночной поездки и включи его") })
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                            }
                            listening = true
                            speechRecognizer.startListening(intent)
                        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }, colors = IconButtonDefaults.filledIconButtonColors(containerColor = if (listening) Accent else Surface2)) {
                        Icon(Icons.Rounded.Mic, contentDescription = "Voice input")
                    }
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (!ai.hasApiKey()) { showKey = true; return@Button }
                        loading = true
                        scope.launch {
                            val result = HazumaAiAgent(ai).run(prompt, tracks, current) { action ->
                                executeHazumaAction(action, tracks, vm, repo)
                            }
                            answer = result.fold({ sources = it.sources; it.text }, { sources = emptyList(); "Ошибка: ${it.message}" })
                            loading = false
                        }
                    },
                    enabled = prompt.isNotBlank() && !loading,
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
                ) { Text(if (loading) "WORKING…" else "ASK HAZUMA AI") }
            }
        }
        if (answer.isNotBlank()) {
            Card(Modifier.padding(20.dp).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface2)) {
                Text(answer, modifier = Modifier.padding(18.dp), lineHeight = 20.sp)
            }
        }
        if (sources.isNotEmpty()) {
            Text("Sources", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            sources.take(5).forEach { (title, uri) ->
                TextButton(onClick = {
                    runCatching { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(uri))) }
                }, modifier = Modifier.padding(horizontal = 12.dp)) {
                    Text(title, maxLines = 1, color = Accent)
                }
            }
        }
        TextButton(onClick = { showKey = true; key = "" }, modifier = Modifier.padding(horizontal = 20.dp)) {
            Text(if (ai.hasApiKey()) "Change Gemini API key" else "Connect Gemini API")
        }
        Text("Internet answers use Gemini's Google Search grounding when the model decides it is useful.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp))
    }
    if (showKey) {
        AlertDialog(
            onDismissRequest = { showKey = false },
            title = { Text("Gemini API key") },
            text = {
                Column {
                    Text("For production, use Firebase AI Logic + App Check rather than shipping a secret key inside the APK.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(key, { key = it }, singleLine = true, placeholder = { Text("AIza…") })
                }
            },
            confirmButton = { TextButton(onClick = { ai.setApiKey(key); showKey = false }) { Text("SAVE") } },
            dismissButton = { TextButton(onClick = { ai.clearApiKey(); showKey = false }) { Text("CLEAR") } }
        )
    }
}

private suspend fun executeHazumaAction(action: HazumaAiAction, tracks: List<MusicTrack>, vm: PlayerViewModel, repo: MusicRepository): String = when (action.name) {
    "play_track" -> {
        val q = action.args.optString("query")
        val t = tracks.firstOrNull { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
        if (t == null) "No matching track found for '$q'." else { vm.play(t); "Playing ${t.title} — ${t.artist}." }
    }
    "pause_playback" -> { vm.pause(); "Playback paused." }
    "next_track" -> { vm.next(); "Skipped to the next track." }
    "previous_track" -> { vm.previous(); "Moved to the previous track." }
    "toggle_shuffle" -> { vm.shuffle(); "Shuffle toggled." }
    "toggle_repeat" -> { vm.repeat(); "Repeat mode changed." }
    "search_library" -> {
        val q = action.args.optString("query")
        tracks.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
            .take(12).joinToString("\n") { "${it.title} — ${it.artist}" }.ifBlank { "No tracks found." }
    }
    "create_playlist" -> {
        val name = action.args.optString("name").ifBlank { "Hazuma AI Mix" }
        val q = action.args.optString("query")
        val matches = if (q.isBlank()) tracks.take(25) else tracks.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }.take(25)
        if (matches.isEmpty()) "No tracks matched '$q', so the playlist was not created."
        else {
            val id = repo.createPlaylist(name)
            matches.forEach { repo.addToPlaylist(id, it.id) }
            "Created playlist '$name' with ${matches.size} tracks."
        }
    }
    else -> "Unknown action: ${action.name}"
}

@Composable private fun SettingsScreen(onClearHistory: () -> Unit, onSleep: () -> Unit) {
    Column {
        Header("Settings", "Hazuma Music")
        SettingRow("Sleep timer", "Stop playback after a chosen time", onSleep)
        SettingRow("Clear listening history", "Remove recent playback records", onClearHistory)
        SettingRow("About Hazuma Music", "Local music player • v1.5.0") {}
    }
}

@Composable private fun SettingRow(title: String, sub: String, onClick: () -> Unit) = Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
    Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(sub, color = Muted, fontSize = 13.sp) }
    Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
}

@Composable private fun GroupRow(title: String, subtitle: String, onClick: () -> Unit) = Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(54.dp).clip(RoundedCornerShape(15.dp)).background(Surface2), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.LibraryMusic, null, tint = Accent) }
    Column(Modifier.weight(1f).padding(start = 14.dp)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 13.sp) }
    Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
}

@Composable private fun SectionTitle(text: String) = Text(text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp))

@Composable private fun TrackRow(t: MusicTrack, fav: Boolean, onClick: (MusicTrack) -> Unit) = Row(Modifier.fillMaxWidth().clickable { onClick(t) }.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
    AlbumCover(t, 58)
    Column(Modifier.weight(1f).padding(start = 14.dp)) { Text(t.title, maxLines = 1, fontWeight = FontWeight.SemiBold); Text("${t.artist} • ${t.album}", maxLines = 1, color = Muted, fontSize = 13.sp) }
    if (fav) Icon(Icons.Rounded.Favorite, null, tint = Accent)
}

@Composable private fun AlbumCover(track: MusicTrack, size: Int) = Box(Modifier.size(size.dp).clip(RoundedCornerShape(15.dp)).background(Surface2), contentAlignment = Alignment.Center) {
    if (track.coverUri != null) AsyncImage(model = track.coverUri, contentDescription = null, modifier = Modifier.fillMaxSize())
    else Icon(Icons.Rounded.MusicNote, null, tint = Accent, modifier = Modifier.size((size * .43f).dp))
}

@Composable private fun MiniPlayer(s: PlayerState, onPlayPause: () -> Unit) = Column(Modifier.fillMaxWidth().background(Surface2).padding(horizontal = 10.dp, vertical = 8.dp)) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (s.track != null) AlbumCover(s.track, 48)
        Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(s.track?.title ?: "Playing", fontWeight = FontWeight.SemiBold, maxLines = 1); Text(s.track?.artist ?: "", color = Muted, fontSize = 12.sp) }
        IconButton(onClick = onPlayPause) { Icon(if (s.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Accent) }
    }
    LinearProgressIndicator(progress = { if (s.duration > 0) s.position.toFloat() / s.duration else 0f }, modifier = Modifier.fillMaxWidth().height(2.dp), color = Accent, trackColor = Color.Transparent)
}

@Composable private fun NowPlaying(s: PlayerState, vm: PlayerViewModel, close: () -> Unit) = Column(Modifier.fillMaxSize().background(Black).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = close) { Icon(Icons.Rounded.KeyboardArrowDown, "Close") }; Text("NOW PLAYING", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Icon(Icons.Rounded.MoreVert, null, tint = Muted) }
    Spacer(Modifier.height(24.dp)); s.track?.let { AlbumCover(it, 340) }; Spacer(Modifier.height(25.dp)); Text(s.track?.title ?: "Unknown", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text(s.track?.artist ?: "", color = Muted)
    Spacer(Modifier.height(18.dp)); Slider(value = { if (s.duration > 0) s.position.toFloat() / s.duration else 0f }, onValueChange = { vm.seek((it * s.duration).toLong()) }, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatMs(s.position), color = Muted, fontSize = 12.sp); Text(formatMs(s.duration), color = Muted, fontSize = 12.sp) }
    Spacer(Modifier.height(15.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = vm::previous) { Icon(Icons.Rounded.SkipPrevious, null, modifier = Modifier.size(34.dp)) }; FilledIconButton(onClick = vm::toggle, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Accent, contentColor = Color.Black), modifier = Modifier.size(70.dp)) { Icon(if (s.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, modifier = Modifier.size(36.dp)) }; IconButton(onClick = vm::next) { Icon(Icons.Rounded.SkipNext, null, modifier = Modifier.size(34.dp)) } }
    Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) { IconButton(onClick = vm::shuffle) { Icon(Icons.Rounded.Shuffle, null, tint = if (s.shuffle) Accent else Muted) }; IconButton(onClick = vm::repeat) { Icon(Icons.Rounded.Repeat, null, tint = if (s.repeatMode != Player.REPEAT_MODE_OFF) Accent else Muted) } }
}

@Composable private fun EmptyState(title: String, text: String, action: () -> Unit) = Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Rounded.LibraryMusic, null, tint = Accent, modifier = Modifier.size(45.dp)); Spacer(Modifier.height(14.dp)); Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(text, color = Muted); Spacer(Modifier.height(15.dp)); Button(onClick = action, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)) { Text("ADD MUSIC") } }

@Composable private fun CreatePlaylistDialog(onCreate: (String) -> Unit, onDismiss: () -> Unit) { var name by remember { mutableStateOf("") }; AlertDialog(onDismissRequest = onDismiss, title = { Text("New playlist") }, text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text("Playlist name") }) }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim()) }) { Text("CREATE") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL") } }) }

@Composable private fun SleepTimerDialog(onSelect: (Int) -> Unit, onCancel: () -> Unit, onDismiss: () -> Unit) { AlertDialog(onDismissRequest = onDismiss, title = { Text("Sleep timer") }, text = { Column { listOf(5, 10, 15, 30, 45, 60).forEach { min -> TextButton(onClick = { onSelect(min) }, modifier = Modifier.fillMaxWidth()) { Text("${min} minutes") } } } }, confirmButton = { TextButton(onClick = onCancel) { Text("TURN OFF") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("CLOSE") } }) }

private fun formatMs(ms: Long): String { val s = ms.coerceAtLeast(0) / 1000; return "%d:%02d".format(s / 60, s % 60) }
