package com.example.mymusic.ai

import android.content.Context

class HazumaAiPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("hazuma_ai", Context.MODE_PRIVATE)
    fun apiKey(): String = prefs.getString("gemini_api_key", "") ?: ""
    fun setApiKey(value: String) { prefs.edit().putString("gemini_api_key", value.trim()).apply() }
    fun clearApiKey() { prefs.edit().remove("gemini_api_key").apply() }
}
