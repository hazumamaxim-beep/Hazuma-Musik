# Hazuma Music 1.2.0

Полноценный исходный проект локального музыкального плеера на Kotlin + Jetpack Compose + Media3 + Room.

## Добавлено в 1.2.0
- embedded album art сохраняется локально и показывается в интерфейсе;
- Artists и Albums в Library;
- Sleep Timer: 5/10/15/30/45/60 минут;
- playback resumption через MediaSession.Callback.onPlaybackResumption;
- MediaButtonReceiver для Bluetooth/системного возобновления;
- очередь и позиция воспроизведения периодически сохраняются;
- восстановление очереди после перезапуска;
- улучшен сканер MediaStore с чтением metadata и обложки;
- обновлён интерфейс Now Playing и mini-player.

## Технологии
- Kotlin / Jetpack Compose
- Media3 1.11.1
- Room 2.8.5
- Coil 3.3.0
- AGP 9.4.0 / JDK 17 / compileSdk 37

Media3 рекомендует держать Player и MediaSession внутри MediaSessionService для фонового воспроизведения; playback resumption требует MediaButtonReceiver и onPlaybackResumption.

## Сборка
Откройте проект в актуальном Android Studio и выполните Gradle Sync, затем Build > Build APK(s). В архиве нет Gradle wrapper JAR, поскольку исходная среда генерации не содержит установленного Gradle.


## Hazuma AI + Internet (v1.3)

The app now includes an optional Gemini-powered AI assistant and secure HTTPS networking.
- Internet permissions: `INTERNET`, `ACCESS_NETWORK_STATE`
- Cloud model: `gemini-3.8-flash` (current stable Gemini Flash model as of September 2026)
- API key is entered by the user in the Hazuma AI screen and stored locally.
- The app sends requests only over HTTPS.
- The AI layer is isolated in `ai/HazumaAiService.kt`, making it straightforward to migrate to Firebase AI Logic + App Check for production.
- On-device Gemini Nano can be added as an offline fallback on supported Android 8+ devices; current v1.3 keeps cloud Gemini as the network feature.

## v1.4 — Hazuma AI Agent + Internet grounding

The AI layer now has two modes:

- local music-agent actions through Gemini function calling: play, pause, next, previous, shuffle, repeat and library search;
- current web answers through Gemini Google Search grounding when the model chooses to use it.

The current stable Gemini 3.x Flash model documented by Firebase AI Logic is `gemini-3.8-flash` (released 2026-09-02). Function calling and Google Search grounding are supported for this model. See the official Firebase AI Logic documentation before production deployment.

### Security before release

The current development build stores a Gemini API key locally so the project can be tested without a Firebase project. **Do not ship a shared secret API key in a production APK.** For release, migrate the AI layer to Firebase AI Logic and enforce Firebase App Check (Play Integrity or another production attestation provider). Firebase states that App Check enforcement is required for AI Logic starting November 2, 2026.

### Internet permissions

The manifest contains `INTERNET` and `ACCESS_NETWORK_STATE`. All network calls should use HTTPS.


## v1.5 AI Music Agent

- Voice input using Android SpeechRecognizer.
- AI tool for creating playlists from natural-language requests.
- AI can search the local library and control playback.
- Gemini 3.8 Flash remains configurable as the default model.
- Internet answers use Google Search grounding when enabled by the model.
- For production, move authentication to Firebase AI Logic + App Check instead of shipping a long-lived secret API key in the APK.
