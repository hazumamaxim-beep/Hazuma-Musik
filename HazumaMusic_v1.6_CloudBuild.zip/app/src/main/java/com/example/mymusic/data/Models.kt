package com.example.mymusic.data

data class MusicTrack(val id:String,val title:String,val artist:String,val album:String,val uri:String,val duration:Long=0,val coverUri:String?=null,val addedAt:Long=0)
data class Playlist(val id:Long,val name:String,val createdAt:Long)
data class PlayerState(val track:MusicTrack?=null,val isPlaying:Boolean=false,val position:Long=0,val duration:Long=0,val shuffle:Boolean=false,val repeatMode:Int=0,val queue:List<MusicTrack> = emptyList(),val currentIndex:Int=-1)
