package com.example.mymusic.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="tracks") data class TrackEntity(@PrimaryKey val id:String,val uri:String,val title:String,val artist:String,val album:String,val duration:Long,val coverUri:String?,val addedAt:Long)
@Entity(tableName="favorites") data class FavoriteEntity(@PrimaryKey val trackId:String)
@Entity(tableName="history") data class HistoryEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val trackId:String,val playedAt:Long)
@Entity(tableName="playlists") data class PlaylistEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val createdAt:Long)
@Entity(tableName="playlist_tracks",primaryKeys=["playlistId","trackId"]) data class PlaylistTrackEntity(val playlistId:Long,val trackId:String,val position:Int)
@Entity(tableName="stats") data class StatEntity(@PrimaryKey val trackId:String,val playCount:Int=0,val totalPlayedMs:Long=0,val lastPlayedAt:Long=0)

@Dao interface MusicDao {
 @Query("SELECT * FROM tracks ORDER BY addedAt DESC") fun tracks():Flow<List<TrackEntity>>
 @Query("SELECT * FROM tracks ORDER BY addedAt DESC") fun tracksNow():List<TrackEntity>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertTracks(v:List<TrackEntity>)
 @Query("DELETE FROM tracks WHERE id=:id") suspend fun deleteTrack(id:String)
 @Query("SELECT trackId FROM favorites") fun favorites():Flow<List<String>>
 @Insert(onConflict=OnConflictStrategy.IGNORE) suspend fun addFavorite(v:FavoriteEntity)
 @Query("DELETE FROM favorites WHERE trackId=:id") suspend fun removeFavorite(id:String)
 @Insert suspend fun history(v:HistoryEntity)
 @Query("SELECT trackId FROM history ORDER BY playedAt DESC LIMIT 100") fun history():Flow<List<String>>
 @Query("DELETE FROM history") suspend fun clearHistory()
 @Query("SELECT * FROM playlists ORDER BY createdAt DESC") fun playlists():Flow<List<PlaylistEntity>>
 @Insert suspend fun createPlaylist(v:PlaylistEntity):Long
 @Query("DELETE FROM playlists WHERE id=:id") suspend fun deletePlaylist(id:Long)
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun addToPlaylist(v:PlaylistTrackEntity)
 @Query("DELETE FROM playlist_tracks WHERE playlistId=:pid AND trackId=:tid") suspend fun removeFromPlaylist(pid:Long,tid:String)
 @Query("SELECT * FROM playlist_tracks WHERE playlistId=:pid ORDER BY position") fun playlistTracks(pid:Long):Flow<List<PlaylistTrackEntity>>
 @Query("SELECT COALESCE(MAX(position),-1)+1 FROM playlist_tracks WHERE playlistId=:pid") suspend fun nextPosition(pid:Long):Int
 @Query("SELECT * FROM stats ORDER BY totalPlayedMs DESC") fun stats():Flow<List<StatEntity>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertStat(v:StatEntity)
 @Query("SELECT * FROM stats WHERE trackId=:id LIMIT 1") suspend fun stat(id:String):StatEntity?
}

@Database(entities=[TrackEntity::class,FavoriteEntity::class,HistoryEntity::class,PlaylistEntity::class,PlaylistTrackEntity::class,StatEntity::class],version=1,exportSchema=false)
abstract class MusicDatabase:RoomDatabase(){
 abstract fun dao():MusicDao
 companion object{ @Volatile private var instance:MusicDatabase?=null
  fun get(c:Context)=instance?:synchronized(this){instance?:Room.databaseBuilder(c.applicationContext,MusicDatabase::class.java,"hazuma_music.db").build().also{instance=it}}
 }
}

fun TrackEntity.model()=MusicTrack(id,title,artist,album,uri,duration,coverUri,addedAt)
fun MusicTrack.entity()=TrackEntity(id,uri,title,artist,album,duration,coverUri,addedAt)
