package com.example.mymusic.player

import android.content.Context
import org.json.JSONArray

class PlaybackPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("playback", Context.MODE_PRIVATE)

    fun save(trackId: String?, position: Long, queue: List<String>) {
        val array = JSONArray().apply { queue.forEach(::put) }
        prefs.edit()
            .putString("track", trackId)
            .putLong("position", position)
            .putString("queue", array.toString())
            .apply()
    }

    fun track(): String? = prefs.getString("track", null)
    fun position(): Long = prefs.getLong("position", 0L)

    fun queue(): List<String> {
        val raw = prefs.getString("queue", null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList { for (i in 0 until array.length()) add(array.getString(i)) }
        }.getOrDefault(emptyList())
    }
}
