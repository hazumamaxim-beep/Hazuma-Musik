package com.example.mymusic.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class HazumaAiService(private val context: Context) {
    companion object {
        // Current stable Gemini Flash model as of Sep 2026. Keep this configurable so it can be
        // switched remotely later without changing the UI.
        const val DEFAULT_MODEL = "gemini-3.8-flash"
    }

    private val client = OkHttpClient()
    private val prefs = HazumaAiPreferences(context)

    fun hasApiKey(): Boolean = prefs.apiKey().isNotBlank()
    fun setApiKey(key: String) = prefs.setApiKey(key)
    fun clearApiKey() = prefs.clearApiKey()

    fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun ask(
        prompt: String,
        contextText: String = ""
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val key = prefs.apiKey()
            require(key.isNotBlank()) { "Добавьте Gemini API key в настройках Hazuma AI." }
            require(isOnline()) { "Нет подключения к интернету." }

            val instruction = """
                You are Hazuma AI, the assistant inside the Hazuma Music Android app.
                Help with music discovery, library organization, playlists, listening habits,
                metadata, and general questions. Be concise and useful. Do not claim access to
                online services or the user's files unless they are included in the context.
                User library context:
                $contextText
            """.trimIndent()

            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction))))
                .put("contents", JSONArray().put(
                    JSONObject().put("role", "user").put(
                        "parts", JSONArray().put(JSONObject().put("text", prompt))
                    )
                ))
                .toString()

            extractText(postGemini(body, key)).ifBlank { "ИИ не вернул текстовый ответ." }
        }
    }


    suspend fun callWithTools(prompt: String, contextText: String): HazumaAiAgentResult = withContext(Dispatchers.IO) {
        val key = prefs.apiKey()
        require(key.isNotBlank()) { "Добавьте Gemini API key в настройках Hazuma AI." }
        require(isOnline()) { "Нет подключения к интернету." }

        val instruction = """
            You are Hazuma AI, an agent inside a local music player.
            You can control playback only through the declared functions.
            Never invent library tracks. Use search_library before choosing a track when needed.
            If the user asks about current information, use Google Search grounding when available.
            Be concise.
            User context:
            $contextText
        """.trimIndent()

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction))))
            .put("tools", JSONArray()
                .put(JSONObject().put("functionDeclarations", toolDeclarations()))
                .put(JSONObject().put("googleSearch", JSONObject())))
            .put("contents", JSONArray().put(
                JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            ))

        val raw = postGemini(body, key)
        val json = JSONObject(raw)
        val parts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
        val actions = mutableListOf<HazumaAiAction>()
        val text = StringBuilder()
        val sources = mutableListOf<Pair<String, String>>()
        val grounding = json.optJSONObject("candidates")?.let { null }
        val groundingMetadata = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("groundingMetadata")
        groundingMetadata?.optJSONArray("groundingChunks")?.let { chunks ->
            for (i in 0 until chunks.length()) {
                val web = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
                val title = web.optString("title")
                val uri = web.optString("uri")
                if (uri.isNotBlank()) sources += title.ifBlank { uri } to uri
            }
        }
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            part.optJSONObject("functionCall")?.let { call ->
                actions += HazumaAiAction(call.optString("name"), call.optJSONObject("args") ?: JSONObject())
            }
            part.optString("text").takeIf { it.isNotBlank() }?.let { if (text.isNotEmpty()) text.append("\n"); text.append(it) }
        }
        HazumaAiAgentResult(text.toString(), actions, sources)
    }

    private fun postGemini(body: JSONObject, key: String): String {
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$DEFAULT_MODEL:generateContent?key=$key")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("Gemini API ${response.code}: ${extractError(raw)}")
            return raw
        }
    }

    private fun extractText(raw: String): String {
        val json = JSONObject(raw)
        val candidates = json.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: return ""
        return buildString {
            for (i in 0 until parts.length()) {
                val text = parts.getJSONObject(i).optString("text")
                if (text.isNotBlank()) {
                    if (isNotEmpty()) append("\n")
                    append(text)
                }
            }
        }
    }

    private fun extractError(raw: String): String = runCatching {
        JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
    }.getOrDefault(raw.take(240))
}
