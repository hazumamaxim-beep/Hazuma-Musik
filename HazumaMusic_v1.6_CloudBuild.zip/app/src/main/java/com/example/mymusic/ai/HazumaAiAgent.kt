package com.example.mymusic.ai

import com.example.mymusic.data.MusicTrack
import org.json.JSONArray
import org.json.JSONObject

data class HazumaAiAction(val name: String, val args: JSONObject)
data class HazumaAiAgentResult(
    val text: String,
    val actions: List<HazumaAiAction> = emptyList(),
    val sources: List<Pair<String, String>> = emptyList()
)

class HazumaAiAgent(private val ai: HazumaAiService) {
    suspend fun run(
        prompt: String,
        tracks: List<MusicTrack>,
        current: MusicTrack?,
        execute: suspend (HazumaAiAction) -> String
    ): Result<HazumaAiAgentResult> = runCatching {
        val library = tracks.take(180).joinToString("\n") { "${it.id} | ${it.title} | ${it.artist} | ${it.album}" }
        val context = "Current: ${current?.title ?: "none"}\nLibrary (${tracks.size} tracks):\n$library"
        val first = ai.callWithTools(prompt, context)
        if (first.actions.isEmpty()) return@runCatching first

        val toolResults = buildString {
            first.actions.take(6).forEach { action ->
                append("Action ${action.name}: ")
                append(execute(action))
                append('\n')
            }
        }
        val final = ai.ask(
            prompt = "Original request: $prompt\n\nActions executed:\n$toolResults\n\nRespond briefly. Confirm completed actions and report useful results. Do not invent anything not contained in the action results.",
            contextText = context
        ).getOrThrow()
        first.copy(text = final, actions = first.actions)
    }
}

internal fun toolDeclarations(): JSONArray = JSONArray().apply {
    put(function("play_track", "Play a library track matching title, artist or album.",
        obj("query")))
    put(function("pause_playback", "Pause current playback.", JSONObject().put("type", "object")))
    put(function("next_track", "Skip to the next track.", JSONObject().put("type", "object")))
    put(function("previous_track", "Go to the previous track.", JSONObject().put("type", "object")))
    put(function("toggle_shuffle", "Toggle shuffle mode.", JSONObject().put("type", "object")))
    put(function("toggle_repeat", "Cycle repeat mode.", JSONObject().put("type", "object")))
    put(function("search_library", "Search the user's local music library.", obj("query")))
    put(function("create_playlist", "Create a playlist and add matching library tracks. Query can describe an artist, album, title or genre-like metadata.",
        JSONObject().put("type", "object").put("properties", JSONObject().put("name", JSONObject().put("type", "string")).put("query", JSONObject().put("type", "string"))).put("required", JSONArray().put("name"))))
}

private fun obj(name: String): JSONObject = JSONObject().put("type", "object")
    .put("properties", JSONObject().put(name, JSONObject().put("type", "string")))
    .put("required", JSONArray().put(name))

private fun function(name: String, description: String, parameters: JSONObject): JSONObject =
    JSONObject().put("name", name).put("description", description).put("parameters", parameters)
