# Hazuma Music — сборка APK с телефона

1. Создайте репозиторий на GitHub.
2. Загрузите содержимое этой папки в репозиторий (ветка `main`).
3. Откройте **Actions** → **Build Hazuma Music APK**.
4. Нажмите **Run workflow**.
5. После завершения откройте запуск workflow и скачайте artifact **HazumaMusic-debug-apk**.
6. Внутри будет APK для установки на Android.

Workflow использует GitHub Actions и Gradle 9.6.0, JDK 17 и публикует APK как artifact.

## Важно про AI

Не помещайте Gemini API key в исходники или GitHub. Для production лучше использовать секреты/серверный прокси или Firebase AI Logic + App Check.
